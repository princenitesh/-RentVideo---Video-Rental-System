package com.example.rentvideo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentvideoApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(RentvideoApiApplication.class, args);
    }
}